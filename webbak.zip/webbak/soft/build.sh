java -jar /Users/liqiu/git/study/web/soft/mybatis-generator-core-1.3.2/lib/mybatis-generator-core-1.3.2.jar -configfile /Users/liqiu/git/study/web/soft/mybatisGeneratorConfig.xml -overwrite
