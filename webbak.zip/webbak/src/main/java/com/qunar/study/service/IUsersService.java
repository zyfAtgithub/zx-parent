package com.qunar.study.service;

import com.qunar.study.entity.Users;

public interface IUsersService {
	public Users getUserById(Integer id);
}
