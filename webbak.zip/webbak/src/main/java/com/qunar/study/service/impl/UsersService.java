package com.qunar.study.service.impl;

import com.qunar.study.entity.Users;
import com.qunar.study.mapper.UsersMapper;
import com.qunar.study.service.IUsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("usersService")
public class UsersService implements IUsersService {

	@Autowired
	private UsersMapper usersMapper;
	
	
	public Users getUserById(Integer id) {
		return usersMapper.selectByPrimaryKey(id);
	}

}
