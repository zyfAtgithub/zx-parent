package test.qunar.com.web;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
import org.springframework.test.context.transaction.TransactionConfiguration;


@TransactionConfiguration(transactionManager = "transactionManager")
@ContextConfiguration(
        locations = {
                "classpath:spring-mybatis.xml",
                "classpath:spring.xml"
        }
)
public abstract class TestBase extends AbstractTransactionalJUnit4SpringContextTests {
}
