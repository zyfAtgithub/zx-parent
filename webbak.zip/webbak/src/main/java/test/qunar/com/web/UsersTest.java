package test.qunar.com.web;

import com.qunar.study.entity.Users;
import com.qunar.study.service.IUsersService;
import org.junit.Test;
import javax.annotation.Resource;

public class UsersTest extends TestBase{
    @Resource
    private IUsersService usersService;

    @Test
    public void testGetMerchant() {
        Users users = usersService.getUserById(10);
        System.out.println(users.getUserId());
    }
}
